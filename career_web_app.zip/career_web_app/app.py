from flask import Flask, render_template, request, jsonify
import joblib
import pandas as pd

app = Flask(__name__)

model = joblib.load("model.pkl")
encoder = joblib.load("encoder.pkl")
features = joblib.load("features.pkl")

def suggest_skills(scores):
    gaps = []
    checks = {
        "Programming": scores.get("Programming", 0),
        "Data Structures and Algorithms": scores.get("DSA", 0),
        "Web Development": scores.get("Web_Dev", 0),
        "AI and Machine Learning": scores.get("AI_ML", 0),
        "Cyber Security Fundamentals": scores.get("Cyber_Security", 0),
        "Communication Skills": scores.get("Communication", 0),
        "Aptitude & Reasoning": scores.get("Aptitude", 0)
    }
    for skill_name, val in checks.items():
        if val < 70:
            gaps.append(f"Improve {skill_name} (Current: {val}/100)")
    return gaps

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.get_json() or {}
    
    row = {
        "CGPA": float(data.get("CGPA", 0.0)),
        "Aptitude": int(data.get("Aptitude", 0)),
        "Programming": int(data.get("Programming", 0)),
        "Maths": int(data.get("Maths", 0)),
        "Communication": int(data.get("Communication", 0)),
        "Logical_Reasoning": int(data.get("Logical_Reasoning", 0)),
        "DSA": int(data.get("DSA", 0)),
        "Web_Dev": int(data.get("Web_Dev", 0)),
        "AI_ML": int(data.get("AI_ML", 0)),
        "Cyber_Security": int(data.get("Cyber_Security", 0)),
        "Projects": int(data.get("Projects", 0)),
        "Internships": int(data.get("Internships", 0)),
        "Certifications": int(data.get("Certifications", 0)),
        "Interest_AI": int(data.get("Interest_AI", 0)),
        "Interest_Web": int(data.get("Interest_Web", 0)),
        "Interest_Data": int(data.get("Interest_Data", 0)),
        "Interest_Security": int(data.get("Interest_Security", 0))
    }
    
    user_df = pd.DataFrame([row], columns=features)
    
    print("\n--- RECEIVED DATA ---")
    print(user_df.to_dict(orient="records"))
    
    probabilities = model.predict_proba(user_df)[0]
    classes = encoder.classes_
    print("Class Probabilities:")
    for cls, prob in zip(classes, probabilities):
        print(f"  {cls}: {round(prob * 100, 2)}%")
    
    pred_idx = model.predict(user_df)[0]
    career = encoder.inverse_transform([pred_idx])[0]
    confidence = float(max(probabilities) * 100)
    gaps = suggest_skills(row)
    
    return jsonify({
        "career": career,
        "confidence": round(confidence, 2),
        "skill_gaps": gaps
    })

if __name__ == "__main__":
    app.run(debug=True, port=5001)