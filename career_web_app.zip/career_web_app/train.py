import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

data = [
    [8.8, 85, 90, 85, 75, 88, 90, 40, 95, 35, 5, 2, 4, 1, 0, 0, 0, "AI Engineer"],
    [8.5, 82, 88, 80, 72, 84, 88, 45, 92, 30, 4, 2, 3, 1, 0, 1, 0, "AI Engineer"],
    [8.2, 80, 85, 78, 70, 80, 85, 50, 90, 35, 3, 1, 2, 1, 0, 0, 0, "AI Engineer"],
    [8.6, 84, 89, 82, 78, 85, 87, 42, 94, 38, 4, 2, 3, 1, 1, 0, 0, "AI Engineer"],
    [8.4, 80, 86, 80, 75, 82, 86, 60, 89, 40, 4, 1, 3, 1, 0, 1, 0, "AI Engineer"],
    
    [8.4, 88, 78, 92, 80, 86, 75, 40, 85, 35, 3, 1, 3, 0, 0, 1, 0, "Data Scientist"],
    [8.2, 85, 76, 90, 78, 84, 74, 35, 82, 30, 3, 1, 2, 0, 0, 1, 0, "Data Scientist"],
    [8.6, 90, 80, 95, 82, 88, 78, 45, 88, 38, 4, 2, 3, 1, 0, 1, 0, "Data Scientist"],
    [8.0, 82, 74, 88, 76, 80, 72, 40, 80, 35, 2, 1, 2, 0, 0, 1, 0, "Data Scientist"],
    [7.8, 80, 72, 86, 75, 78, 70, 50, 78, 32, 2, 1, 1, 0, 0, 1, 0, "Data Scientist"],

    [7.4, 68, 78, 62, 75, 72, 70, 92, 35, 30, 4, 2, 2, 0, 1, 0, 0, "Web Developer"],
    [7.2, 65, 75, 60, 78, 68, 68, 90, 30, 28, 3, 1, 2, 0, 1, 0, 0, "Web Developer"],
    [7.0, 62, 72, 58, 80, 65, 65, 88, 25, 25, 2, 1, 1, 0, 1, 0, 0, "Web Developer"],
    [7.6, 70, 80, 65, 74, 74, 72, 94, 38, 32, 3, 1, 2, 0, 1, 0, 0, "Web Developer"],
    [7.5, 66, 76, 64, 76, 70, 70, 89, 40, 30, 3, 1, 2, 1, 1, 0, 0, "Web Developer"],

    [8.3, 82, 92, 80, 74, 85, 94, 60, 50, 45, 4, 2, 3, 0, 0, 0, 0, "Software Engineer"],
    [8.0, 78, 88, 76, 70, 80, 90, 55, 45, 40, 3, 1, 2, 0, 1, 0, 0, "Software Engineer"],
    [8.5, 84, 94, 82, 78, 86, 95, 65, 55, 42, 5, 2, 3, 0, 0, 0, 0, "Software Engineer"],
    [7.8, 75, 86, 74, 68, 78, 88, 52, 42, 38, 3, 1, 2, 0, 0, 0, 0, "Software Engineer"],
    [8.1, 80, 90, 78, 72, 82, 92, 58, 48, 40, 4, 2, 2, 0, 0, 0, 0, "Software Engineer"],

    [8.2, 82, 78, 74, 75, 85, 76, 40, 35, 94, 4, 2, 3, 0, 0, 0, 1, "Cyber Security Analyst"],
    [7.9, 78, 74, 70, 72, 80, 72, 35, 30, 90, 3, 1, 2, 0, 0, 0, 1, "Cyber Security Analyst"],
    [8.4, 85, 80, 76, 78, 88, 78, 45, 40, 96, 4, 2, 4, 0, 0, 0, 1, "Cyber Security Analyst"],
    [7.7, 75, 72, 68, 70, 78, 70, 32, 28, 88, 2, 1, 1, 0, 0, 0, 1, "Cyber Security Analyst"],
    [8.0, 80, 76, 72, 74, 82, 74, 38, 34, 92, 3, 2, 2, 0, 1, 0, 1, "Cyber Security Analyst"],
    
    [8.5, 85, 88, 82, 78, 84, 86, 80, 85, 50, 4, 2, 3, 1, 1, 1, 0, "AI Engineer"],
    [8.0, 80, 84, 86, 75, 80, 82, 75, 82, 78, 4, 2, 3, 1, 1, 1, 1, "Software Engineer"]
]

columns = [
    "CGPA", "Aptitude", "Programming", "Maths", "Communication",
    "Logical_Reasoning", "DSA", "Web_Dev", "AI_ML", "Cyber_Security",
    "Projects", "Internships", "Certifications",
    "Interest_AI", "Interest_Web", "Interest_Data", "Interest_Security",
    "Career_Label"
]

df = pd.DataFrame(data, columns=columns)

label_encoder = LabelEncoder()
df["Career_Label"] = label_encoder.fit_transform(df["Career_Label"])

X = df.drop("Career_Label", axis=1)
y = df["Career_Label"]

model = RandomForestClassifier(
    n_estimators=100,
    max_features=None,
    criterion="entropy",
    random_state=42
)
model.fit(X, y)

joblib.dump(model, "model.pkl")
joblib.dump(label_encoder, "encoder.pkl")
joblib.dump(list(X.columns), "features.pkl")
print("Retrained and serialized successfully.")